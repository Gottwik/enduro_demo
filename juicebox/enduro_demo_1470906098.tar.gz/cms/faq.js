{
	slider_context: {
		short: true,
		slides: [
			{
				image: 'https://static.pexels.com/photos/5317/food-salad-restaurant-person-large.jpg'
			},
			{
				image: 'https://static.pexels.com/photos/41123/pexels-photo-41123-large.jpeg'
			},
			{
				image: 'https://static.pexels.com/photos/62097/pexels-photo-62097-large.jpeg'
			}
		],
	},
	faq: [
		{
			question: 'I have a lobster that I believe might be spoiled, would you be ok to taste it for me? I really don\'t want to throw it out',
			answer: 'Ehm, sure. So how spoiled are we talking about?'
		}
	]
}