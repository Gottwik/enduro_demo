{
	settings: {
		$admin_background_image_type: 'image',
		admin_background_image: 'https://s3-eu-west-1.amazonaws.com/enduro.demo/direct_uploads/1470906095_pexels-photo-27484.jpg'
	}
}