{
	settings: {
		$admin_background_image_type: 'image',
		admin_background_image: {}
	}
}