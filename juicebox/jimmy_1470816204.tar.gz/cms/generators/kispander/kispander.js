{
	$modules_hidetitle: true,
	$modules_size: 12,
	$modules_templatitator: '@@global.kispander_modules',
	modules: []
}