{
	$modules_hidetitle: true,
	$modules_size: 12,
	$modules_templatitator: '@@global.kispander_modules',
	modules: [
		{
			$module_type_hidden: true,
			module_type: 'kispander_fullimage',
			$context_noframe: true,
			context: {
				$img_type: 'image',
				img: '/assets/img/boxcards/geraldlookingatthings.jpg'
			}
		}
	]
}