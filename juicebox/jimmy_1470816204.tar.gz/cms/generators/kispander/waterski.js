{
	$modules_hidetitle: true,
	$modules_size: 12,
	$modules_templatitator: '@@global.kispander_modules',
	modules: [
		{
			$module_type_hidden: true,
			module_type: 'kispander_fullimage',
			$context_noframe: true,
			context: {
				$img_type: 'image',
				img: 'https://s3-eu-west-1.amazonaws.com/enduro.static/direct_uploads/1467273011_kispander_Teamday_Waterski.jpg'
			}
		}
	]
}