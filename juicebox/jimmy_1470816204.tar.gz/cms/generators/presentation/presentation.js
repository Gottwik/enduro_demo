{
	name: '',
	$slides_templatitator: '@@global.slides',
	$slides_size: 6,
	slides: []
}