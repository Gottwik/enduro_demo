{
	$kispander_link_color_type: 'colorpicker',
	kispander_link_color: '#000',
	$modules_hidetitle: true,
	$modules_size: 12,
	$modules_templatitator: '@@global.modules',
	modules: [
		{
			$module_type_type: 'title',
			module_type: 'jumbotron',
			$context_expander: true,
			$context_noframe: true,
			context: {
				$background_img_type: 'image',
				$background_img_label: 'Background image',
				background_img: 'https://s3-eu-west-1.amazonaws.com/enduro.static/direct_uploads/1469647504_big_banner.jpg',
				$background_video_type: 'image',
				background_video: '',
				$veil_info: 'Select opacity of the veil.',
				$veil_type: 'slider',
				veil: '15',
				$veilcolor_info: 'Choose a color for the veil. Defaults to black.',
				$veilcolor_type: 'colorpicker',
				veilcolor: '#000',
				$jumbotext_type: 'textarea',
				jumbotext: 'This is a story about an industry veteran shaking up e-mobility.',
				gradient_top: false,
				gradient_bottom: false
			}
		},
		{
			$module_type_type: 'title',
			module_type: 'simpleton',
			$context_expander: true,
			$context_noframe: true,
			context: {
				module_name: 'Light bulb moment',
				social: true,
				$background_img_type: 'image',
				background_img: '',
				$background_video_type: 'image',
				background_video: '',
				$veil_info: 'Select opacity of the veil.',
				$veil_type: 'slider',
				veil: 0,
				$veilcolor_info: 'Choose a color for the veil. Defaults to black.',
				$veilcolor_type: 'colorpicker',
				veilcolor: '#000',
				dark: false,
				$columns_hidetitle: true,
				$columns_templatitator: '@@global.simpleton_modules',
				$columns_min: 1,
				$columns_max: 2,
				columns: [
					{
						$simpleton_type_hidden: true,
						simpleton_type: 'simpleton_text',
						$context_noframe: true,
						context: {
							header: '',
							title: 'Back in the [“good old days”]{heritage}, when there was no industry standard for connecting cables...',
							$text_type: 'textarea',
							text: '...one company set out to change the game. Their pioneering work remains industry standard to this day. MENNEKES is now the leading manufacturer of industrial plugs and connectors worldwide, and continues to push the industry into new territories with high-quality products “Made in Germany”. And, now, they’re charging into a new world: e-mobility.',
							purelink: ''
						}
					}
				]
			}
		},
		{
			$module_type_type: 'title',
			module_type: 'jumbotron',
			$context_expander: true,
			$context_noframe: true,
			context: {
				$background_img_type: 'image',
				$background_img_label: 'Background image',
				background_img: 'https://s3-eu-west-1.amazonaws.com/enduro.static/direct_uploads/1469647534_big_picture_1.jpg',
				$background_video_type: 'image',
				background_video: '',
				$veil_info: 'Select opacity of the veil.',
				$veil_type: 'slider',
				veil: 5,
				$veilcolor_info: 'Choose a color for the veil. Defaults to black.',
				$veilcolor_type: 'colorpicker',
				veilcolor: '#000',
				$jumbotext_type: 'textarea',
				jumbotext: '',
				gradient_top: false,
				gradient_bottom: false
			}
		},
		{
			$module_type_type: 'title',
			module_type: 'simpleton',
			$context_expander: true,
			$context_noframe: true,
			context: {
				module_name: 'Get amped',
				social: false,
				$background_img_type: 'image',
				background_img: '',
				$background_video_type: 'image',
				background_video: '',
				$veil_info: 'Select opacity of the veil.',
				$veil_type: 'slider',
				veil: 0,
				$veilcolor_info: 'Choose a color for the veil. Defaults to black.',
				$veilcolor_type: 'colorpicker',
				veilcolor: '#000',
				dark: false,
				$columns_hidetitle: true,
				$columns_templatitator: '@@global.simpleton_modules',
				$columns_min: 1,
				$columns_max: 2,
				columns: [
					{
						$simpleton_type_hidden: true,
						simpleton_type: 'simpleton_text',
						$context_noframe: true,
						context: {
							header: '',
							title: 'Getting [amped]{designprocess} about E-mobility',
							$text_type: 'textarea',
							text: 'MENNEKES teamed up with KISKA to bring their expertise in standardized plugs and industrial variants to the e-mobility sector. Once again it was a pioneer! We didn’t just design a wall charger (which is totally unique in terms of ease-of-use, design and flexibility). We looked ahead with the client, giving them the tools to challenge preconceptions about e-mobility. Future electric transportation had to be accessible and intuitive – perfect for everyday use. Eventually, this concept was even given a name: “Charge Up Your Day!”',
							purelink: ''
						}
					}
				]
			}
		},
		{
			$module_type_type: 'title',
			module_type: 'squarebox',
			$context_expander: true,
			$context_noframe: true,
			context: {
				$squares_hidetitle: true,
				reversed: false,
				$squares_templatitator: '@@global.squares',
				squares: [
					{
						$square_type_hidden: true,
						square_type: 'square_text',
						$context_noframe: true,
						context: {
							$img_type: 'image',
							img: 'https://s3-eu-west-1.amazonaws.com/enduro.static/direct_uploads/1469647600_1_big.jpg',
							hashtags: '',
							title: '',
							text: '',
							link: ''
						}
					},
					{
						$square_type_hidden: true,
						square_type: 'square_text',
						$context_noframe: true,
						context: {
							$img_type: 'image',
							img: 'https://s3-eu-west-1.amazonaws.com/enduro.static/direct_uploads/1469647608_2_big.jpg',
							hashtags: '',
							title: '',
							text: '',
							link: ''
						}
					}
				]
			}
		},
		{
			$module_type_type: 'title',
			module_type: 'simpleton',
			$context_expander: true,
			$context_noframe: true,
			context: {
				module_name: 'It worked out',
				social: false,
				$background_img_type: 'image',
				background_img: '',
				$background_video_type: 'image',
				background_video: '',
				$veil_info: 'Select opacity of the veil.',
				$veil_type: 'slider',
				veil: 0,
				$veilcolor_info: 'Choose a color for the veil. Defaults to black.',
				$veilcolor_type: 'colorpicker',
				veilcolor: '#000',
				dark: false,
				$columns_hidetitle: true,
				$columns_templatitator: '@@global.simpleton_modules',
				$columns_min: 1,
				$columns_max: 2,
				columns: [
					{
						$simpleton_type_hidden: true,
						simpleton_type: 'simpleton_text',
						$context_noframe: true,
						context: {
							header: '',
							title: 'The plan [worked.]{transparency} The MENNEKES Connector is the EU standard for all electric vehicles.',
							$text_type: 'textarea',
							text: '',
							purelink: ''
						}
					},
					{
						$simpleton_type_hidden: true,
						simpleton_type: 'simpleton_text',
						$context_noframe: true,
						context: {
							header: '',
							title: '',
							$text_type: 'textarea',
							text: 'A “one size fits all” solution is never easy, but it was even trickier than usual in this case. Working shoulder to shoulder with the automotive industry and energy service providers, MENNEKES now plays a key role in e-mobility. They continue to do what they do best: pioneer and engineer, connect people and make their day-to-day life easier.',
							link: ''
						}
					}
				]
			}
		},
		{
			$module_type_type: 'title',
			module_type: 'jumbotron',
			$context_expander: true,
			$context_noframe: true,
			context: {
				$background_img_type: 'image',
				$background_img_label: 'Background image',
				background_img: 'https://s3-eu-west-1.amazonaws.com/enduro.static/direct_uploads/1469647638_slide_1.jpg',
				$background_video_type: 'image',
				background_video: 'https://s3-eu-west-1.amazonaws.com/enduro.static/direct_uploads/1469649636_loop_video.mp4',
				$veil_info: 'Select opacity of the veil.',
				$veil_type: 'slider',
				veil: 5,
				$veilcolor_info: 'Choose a color for the veil. Defaults to black.',
				$veilcolor_type: 'colorpicker',
				veilcolor: '#000',
				$jumbotext_type: 'textarea',
				jumbotext: '',
				gradient_top: true,
				gradient_bottom: true
			}
		},
		{
			$module_type_type: 'title',
			module_type: 'simpleton',
			$context_expander: true,
			$context_noframe: true,
			context: {
				module_name: 'Conversion',
				social: false,
				$background_img_type: 'image',
				background_img: '',
				$background_video_type: 'image',
				background_video: '',
				$veil_info: 'Select opacity of the veil.',
				$veil_type: 'slider',
				veil: 0,
				$veilcolor_info: 'Choose a color for the veil. Defaults to black.',
				$veilcolor_type: 'colorpicker',
				veilcolor: '#000',
				dark: false,
				$columns_hidetitle: true,
				$columns_templatitator: '@@global.simpleton_modules',
				$columns_min: 1,
				$columns_max: 2,
				columns: [
					{
						$simpleton_type_hidden: true,
						simpleton_type: 'simpleton_text',
						$context_noframe: true,
						context: {
							header: '',
							title: '[Converting]{launch} MENNEKES from a manufacturer to a consumer brand.',
							$text_type: 'textarea',
							text: 'Getting from point A to B emission-free is no longer science fiction. The dawn of e-mobility is here, and us everyday people didn’t even have to consciously look for it. Once the groundwork was laid by environmentalists, experts and governments, we found that in the end we encouraged ourselves to “go green”.\n\nThe e-Mobility movement isn’t a different way. It’s a better way.',
							purelink: ''
						}
					}
				]
			}
		},
		{
			$module_type_type: 'title',
			module_type: 'jumbotron',
			$context_expander: true,
			$context_noframe: true,
			context: {
				$background_img_type: 'image',
				$background_img_label: 'Background image',
				background_img: 'https://s3-eu-west-1.amazonaws.com/enduro.static/direct_uploads/1469647658_big_picture_with_txt.jpg',
				$background_video_type: 'image',
				background_video: '',
				$veil_info: 'Select opacity of the veil.',
				$veil_type: 'slider',
				veil: 5,
				$veilcolor_info: 'Choose a color for the veil. Defaults to black.',
				$veilcolor_type: 'colorpicker',
				veilcolor: '#000',
				$jumbotext_type: 'textarea',
				jumbotext: 'Now, it’s about nourishing a community and energising the key players.',
				gradient_top: false,
				gradient_bottom: false
			}
		},
		{
			$module_type_type: 'title',
			module_type: 'simpleton',
			$context_expander: true,
			$context_noframe: true,
			context: {
				module_name: '',
				social: false,
				$background_img_type: 'image',
				background_img: '',
				$background_video_type: 'image',
				background_video: '',
				$veil_info: 'Select opacity of the veil.',
				$veil_type: 'slider',
				veil: '97',
				$veilcolor_info: 'Choose a color for the veil. Defaults to black.',
				$veilcolor_type: 'colorpicker',
				veilcolor: '#000',
				dark: true,
				$columns_hidetitle: true,
				$columns_templatitator: '@@global.simpleton_modules',
				$columns_min: 1,
				$columns_max: 2,
				columns: [
					{
						$simpleton_type_hidden: true,
						simpleton_type: 'simpleton_text',
						$context_noframe: true,
						context: {
							header: 'Stop waiting. Start connecting!',
							title: 'Let\'s charge up an industry together.',
							$text_type: 'textarea',
							text: '',
							link: 'Get in touch'
						}
					}
				]
			}
		}
	]
}