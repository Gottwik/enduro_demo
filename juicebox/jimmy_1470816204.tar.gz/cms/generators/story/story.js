{
	$kispander_link_color_type: 'colorpicker',
	kispander_link_color: '#000',
	$modules_hidetitle: true,
	$modules_size: 12,
	$modules_templatitator: '@@global.modules',
	modules: []
}