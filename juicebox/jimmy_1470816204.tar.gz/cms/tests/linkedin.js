{
	linkedin: 'https://www.linkedin.com/company/kiska/comments?topic=6159265201620340736'
}