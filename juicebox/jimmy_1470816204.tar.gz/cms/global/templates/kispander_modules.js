{
	kispander_modules: {
		kispander_fullimage: {
			$module_type_hidden: true,
			module_type: 'kispander_fullimage',
			$context_noframe: true,
			context: {
				$img_type: 'image',
				img: '/assets/img/boxcards/geraldlookingatthings.jpg'
			}
		}
	}
}