{
	slider_context: {
		short: true,
		slides: [
			{
				image: 'https://static.pexels.com/photos/5317/food-salad-restaurant-person-large.jpg'
			},
			{
				image: 'https://static.pexels.com/photos/41123/pexels-photo-41123-large.jpeg'
			},
			{
				image: 'https://static.pexels.com/photos/62097/pexels-photo-62097-large.jpeg'
			}
		],
	}
}