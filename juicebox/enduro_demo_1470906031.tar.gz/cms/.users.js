{
	users: [
		{
			username: 'gottwik',
			salt: '1d2a2ec61f7a6951f6d435f3032c4b89',
			hash: '0ebaee25856653053da3e2ea4f989d4aed29c32b5dcdfc264d34cc72ef7f62a3',
			user_created_timestamp: 1465969880306
		},
	]
}