{
	settings: {
		$admin_background_image_type: 'image',
		admin_background_image: 'https://s3-eu-west-1.amazonaws.com/enduro.demo/direct_uploads/1470906026_pexels-photo-92997.jpeg'
	}
}